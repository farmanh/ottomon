import {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
} from "./chunk-XTP5MKUX.js";
import "./chunk-XH7PH2UX.js";
import "./chunk-HR7ETXTP.js";
import "./chunk-PEQT6LCE.js";
export {
  outputFromObservable,
  outputToObservable,
  takeUntilDestroyed,
  toObservable,
  toSignal
};
//# sourceMappingURL=@angular_core_rxjs-interop.js.map
