import {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
} from "./chunk-VIOFKPFU.js";
import "./chunk-4E3FZW2T.js";
import "./chunk-OUZDZVOA.js";
import "./chunk-XH7PH2UX.js";
import "./chunk-HR7ETXTP.js";
import "./chunk-PEQT6LCE.js";
export {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
};
//# sourceMappingURL=@coreui_icons-angular.js.map
