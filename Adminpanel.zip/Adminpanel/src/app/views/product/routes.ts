import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'addProduct',
    loadComponent: () => import('./add-product/add-product.component').then(m => m.AddProductComponent),
    data: {
      title: 'Add Product'
    }
  },
  {
    path: 'productList',
    loadComponent: () => import('./product-list/product-list.component').then(m => m.ProductListComponent),
    data: {
      title: 'Product list'
    }
  },
 
];
