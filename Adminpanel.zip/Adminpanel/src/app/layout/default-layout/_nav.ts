import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
    // badge: {
    //   color: 'info',
    //   text: 'NEW'
    // }
  },
  {
    title: true,
    name: 'Product Management'
  },
  // {
  //   name: 'Colors',
  //   url: '/theme/colors',
  //   iconComponent: { name: 'cil-drop' }
  // },
  // {
  //   name: 'Typography',
  //   url: '/theme/typography',
  //   linkProps: { fragment: 'headings' },
  //   iconComponent: { name: 'cil-pencil' }
  // },
  // {
  //   name: 'Components',
  //   title: true
  // },
 

  {
    name: 'Produts',
    url: '/product',
    iconComponent: { name: 'cilBasket' },
    children: [
      {
        name: 'Add Product',
        url: 'product//addProduct',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Products List',
        url: '/product/productList',
        icon: 'nav-icon-bullet'
      },
      
    ]
  },
  {
    title: true,
    name: 'Links',
    class: 'mt-auto'
  },
 
];
